
# Playwright TypeScript Enterprise Framework

## Setup
1. Install NodeJS 18+
2. Run:
   npm install
3. Install browsers:
   npx playwright install

## Run Tests
Headless:
npm test

Headed:
npm run test:headed

View Report:
npm run report

## What was converted
Robot Framework Selenium keyword that:
- Opened Chrome in headless
- Set window size
- Waited for sign-in element
- Validated page load
- Captured browser PID

Converted to Playwright TypeScript using:
- Chromium launch options
- Native waitForSelector
- Built-in retry & trace
- HTML reporting

## Improvements
- No manual driver management
- Stable waits (no sleeps)
- Automatic tracing
- Built-in reporting
- Faster execution

## Summary
The original Selenium Robot keyword relied on ChromeOptions and explicit waits.
Playwright natively handles synchronization, browser management, and tracing.
The conversion reduced flaky behavior and improved performance while preserving functionality.
