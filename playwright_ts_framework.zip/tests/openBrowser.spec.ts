
import { test, expect } from '@playwright/test';
import { openBrowserWithUrl } from '../src/core/browser';

test('Open site and verify sign element', async () => {
  const url = 'https://example.com';
  const waitXpath = "(//a[contains(text(),'Sign')])[1]";

  const { browser, page, pid } = await openBrowserWithUrl(url, waitXpath);

  console.log("Browser PID:", pid);

  const element = await page.locator(`xpath=${waitXpath}`);
  await expect(element).toBeVisible();

  await browser.close();
});
