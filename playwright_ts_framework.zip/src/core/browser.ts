
import { chromium, Browser, Page } from '@playwright/test';

export async function openBrowserWithUrl(url: string, waitXpath: string) {
  const browser: Browser = await chromium.launch({
    headless: true,
    args: ['--disable-gpu','--no-sandbox','--disable-dev-shm-usage']
  });

  const context = await browser.newContext({
    viewport: { width: 1920, height: 1080 }
  });

  const page: Page = await context.newPage();
  await page.goto(url, { waitUntil: 'domcontentloaded' });

  // wait for sign element
  try {
    await page.waitForSelector(`xpath=${waitXpath}`, { timeout: 30000 });
  } catch (e) {
    throw new Error("Unable to launch the URL or Sign element not visible");
  }

  const pid = browser.process()?.pid ?? 0;
  return { browser, page, pid };
}
