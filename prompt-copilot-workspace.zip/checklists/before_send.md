
Before sending prompt ensure:
[ ] Mention framework
[ ] Mention language
[ ] Mention environment
[ ] Ask for assertions
[ ] Ask for error handling
[ ] Ask for reporting
