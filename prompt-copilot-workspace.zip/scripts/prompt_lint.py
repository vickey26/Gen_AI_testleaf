
import sys, re
path = sys.argv[1]
text = open(path,encoding='utf-8').read().lower()

sections = ["role","context","objective","response format","constraints"]
missing = [s for s in sections if s not in text]

if missing:
    print("Missing sections:", ", ".join(missing))
else:
    print("Prompt structure looks good!")
