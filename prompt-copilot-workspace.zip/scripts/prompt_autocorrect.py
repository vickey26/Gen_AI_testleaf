
import sys, pathlib

raw = open(sys.argv[1],encoding='utf-8').read()

template = f'''
# ROLE
You are a Senior Automation Architect specialized in Robot Framework and Python.

# CONTEXT
Automation Testing Project

# OBJECTIVE
{raw.strip()}

# STYLE
Enterprise, maintainable, reusable.

# TONE
Technical and clear.

# AUDIENCE
Automation engineers.

# RESPONSE FORMAT
Return code blocks and explanations.

# CONSTRAINTS
Include assertions, reporting, logging, and edge cases.
'''

open(sys.argv[1],'w',encoding='utf-8').write(template)
print("Prompt Auto-Corrected!")
