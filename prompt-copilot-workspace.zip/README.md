
# Prompt Copilot Workspace (for Automation Testers – Python + Robot Framework)

This workspace teaches you how to write **effective prompts** even if you’ve never written one before.
It uses the **CO-STAR** framework (Context, Objective, Style, Tone, Audience, Response) — a widely used industry structure for reliable AI outputs.

## What this gives you
- Ready-made prompt templates
- Auto-correction (fixes weak prompts into strong prompts)
- Lint checker (tells you what is missing)
- VS Code snippets
- Examples for UI & API automation

---

## Step 1 — Open the workspace
1. Install **VS Code**
2. Extract this zip
3. Open `prompt-copilot.code-workspace` in VS Code

---

## Step 2 — Write your first prompt
Create a file inside `/my-prompts/`
Example:
```
my-prompts/login_test.prompt.md
```

Then type your raw thought (DON’T worry about grammar):

```
i want robot framework login test for invalid password cases
```

---

## Step 3 — Auto Correct your prompt
Open Terminal in VS Code and run:

```
python scripts/prompt_autocorrect.py my-prompts/login_test.prompt.md
```

The system will:
• Convert it into a structured professional prompt  
• Add constraints  
• Add expected output format  
• Add test coverage instructions  

---

## Step 4 — Check quality (VERY IMPORTANT)
Run:

```
python scripts/prompt_lint.py my-prompts/login_test.prompt.md
```

It will tell:
- Missing context
- Missing output format
- Vague instructions
- Bad wording

---

## Step 5 — Send to AI (ChatGPT / Copilot)
Now copy the corrected prompt → send to AI → you will get **enterprise-level answers**.

---

## Golden Rule
Never prompt like this:
> "write automation code"

Always prompt like this:
> structured + constraints + format + role

The workspace does that automatically.

---

## Best Practice for Automation Testers
Always include:
• Framework (Robot / Pytest / Playwright)
• Language (Python)
• Environment (QA/UAT/Prod)
• Output format (code only / explanation + code / folder structure)
• Edge cases
• Reporting
• Assertions

---

You now have a **Prompt Engineer Assistant**.
